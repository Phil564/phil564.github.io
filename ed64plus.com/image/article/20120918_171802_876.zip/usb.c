
volatile u32 *regs_ptr = (u32 *) 0xA8040000;
#define REG_CFG 0
#define REG_STATUS 1
#define REG_DMA_LEN 2
#define REG_DMA_RAM_ADDR 3
#define REG_MSG 4
#define REG_DMA_CFG 5
#define REG_SPI 6
#define REG_SPI_CFG 7
#define REG_KEY 8
#define REG_SAV_CFG 9
#define REG_SEC 10
#define REG_VER 11


#define ED_STATE_DMA_BUSY 0
#define ED_STATE_DMA_TOUT 1
#define ED_STATE_TXE 2
#define ED_STATE_RXF 3
#define ED_STATE_SPI 4

#define DCFG_SD_TO_RAM 1
#define DCFG_RAM_TO_SD 2
#define DCFG_FIFO_TO_RAM 3
#define DCFG_RAM_TO_FIFO 4

#define EVD_ERROR_FIFO_TIMEOUT 90;
#define EVD_ERROR_MMC_TIMEOUT 91;


//unlock everdrive registers
void everdriveUnlock() {
    volatile u8 val;
    val = regs_ptr[0];
    regs_ptr[REG_KEY] = 0x1234; //unlock everdrive
    //now you have access to everdrive hardware and cart momy is not read only anymore
}

u8 evd_isDmaTimeout() {

    u16 val;
    //regs_ptr[REG_STATE]++;
    val = regs_ptr[REG_STATUS];

    return (val >> ED_STATE_DMA_TOUT) & 1;
}

//everdrive dma controller state
u8 evd_isDmaBusy() {

    u16 val;
    //volatile u32 i;
    sleep(1);//not necassary

    //regs_ptr[REG_STATE]++;
    val = regs_ptr[REG_STATUS];
    return (val >> ED_STATE_DMA_BUSY) & 1;
}


//everdrive transfers data from/to rom memory, and not directly to n64 ram
//transfer from PC to cart memory
//dst address in cart address space. must me aligned to 2048. len in blocks. block = 512bytes
u8 evd_fifoRdToCart(u32 cart_addr, u16 blocks) {

    volatile u8 val;
    cart_addr /= 2048;


    val = regs_ptr[0];
    regs_ptr[REG_DMA_LEN] = (blocks - 1);
    val = regs_ptr[0];
    regs_ptr[REG_DMA_RAM_ADDR] = cart_addr;
    val = regs_ptr[0];
    regs_ptr[REG_DMA_CFG] = DCFG_FIFO_TO_RAM;

    while (evd_isDmaBusy());
    if (evd_isDmaTimeout())return EVD_ERROR_FIFO_TIMEOUT;


    return 0;
}

//transfer from cart memory to PC
//src address in cart address space. must me aligned to 2048. len in blocks. block = 512bytes
u8 evd_fifoWrFromCart(u32 cart_addr, u16 blocks) {

    volatile u8 val;
    cart_addr /= 2048;


    val = regs_ptr[0];
    regs_ptr[REG_DMA_LEN] = (blocks - 1);
    val = regs_ptr[0];
    regs_ptr[REG_DMA_RAM_ADDR] = cart_addr;
    val = regs_ptr[0];
    regs_ptr[REG_DMA_CFG] = DCFG_RAM_TO_FIFO;

    while (evd_isDmaBusy());
    if (evd_isDmaTimeout())return EVD_ERROR_FIFO_TIMEOUT;

    return 0;
}

//some data availalbe on usb buffer
u8 evd_fifoRxf() {

    u16 val;
    //regs_ptr[REG_STATE]++;
    val = regs_ptr[REG_STATUS];
    return (val >> ED_STATE_RXF) & 1;
}

//usb ready to transfer
u8 evd_fifoTxe() {

    u16 val;
    //regs_ptr[REG_STATE]++;
    val = regs_ptr[REG_STATUS];
    return (val >> ED_STATE_TXE) & 1;
}
